package com.circlecrop.android;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup.LayoutParams;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CircleCrop extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /**
        setContentView(R.layout.main);
        **/
        TextView tv = new TextView(this);
        tv.setText("Working...");
        setContentView(tv);

        LinearLayout m = new LinearLayout(this);
        
        ImageView i = new ImageView(this);
        i.setDrawingCacheBackgroundColor(1);
        
        //cropped here
        Bitmap b = circleCropResource(getResources(),R.drawable.ex2);
        i.setImageBitmap(b);
        
        i.setAdjustViewBounds(true);
        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        m.addView(i);
        setContentView(m);
    }
    public Bitmap circleCropResource(Resources res, int id){
    	Bitmap b = BitmapFactory.decodeResource(res,id);
    	b = circleCropBitmap(b);
    	return b;
    }
    public Bitmap circleCropBitmap(Bitmap b){
    	Bitmap bg = Bitmap.createBitmap(b.getWidth(),b.getHeight(),Bitmap.Config.ARGB_8888);
    	Canvas c = new Canvas(bg);
    	c.drawBitmap(b, 0, 0, new Paint());
    	
    	Path p = new Path();
    	p.addCircle(b.getWidth()/2F,b.getHeight()/2F,b.getWidth()/2F,Path.Direction.CW);
    	c.clipPath(p,Region.Op.DIFFERENCE);
    	c.drawColor(0x00000000, PorterDuff.Mode.CLEAR);
    	return bg;
    }
}